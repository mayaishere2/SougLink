package com.example.souglink

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
