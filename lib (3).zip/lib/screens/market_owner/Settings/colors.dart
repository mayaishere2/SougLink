
import 'dart:ui';

Color mainBlack= const Color.fromARGB(255, 15, 75, 6);
Color secondBlack = const Color(0xff292929);
Color mainGreen= const Color.fromARGB(255, 228, 243, 226);
Color inputHint=const Color(0xffB3B3B3);

Color thirdBlack = const Color(0xff565656);