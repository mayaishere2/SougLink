import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:souglink/bloc/login_cubit.dart';
import 'package:souglink/screens/market_owner/MainPageSeller.dart';
import 'package:souglink/screens/farmer/MainPageFarmer.dart';
import 'package:souglink/screens/login_signup/signup_page.dart';
import '/databases/database_user.dart'; // For UserDatabase

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginState();
}

class _LoginState extends State<LoginPage> {
  final FocusNode _usernameFocusNode = FocusNode();
  final FocusNode _passwordFocusNode = FocusNode();
  Color _usernameFillColor = const Color.fromARGB(107, 255, 255, 255);
  Color _passwordFillColor = const Color.fromARGB(107, 255, 255, 255);
  bool _isVisible = false;

  // Controllers for the text fields
  final TextEditingController _usernameController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _usernameFocusNode.addListener(() {
      setState(() {
        _usernameFillColor = _usernameFocusNode.hasFocus
            ? const Color.fromARGB(0, 255, 255, 255)
            : const Color.fromARGB(107, 255, 255, 255);
      });
    });
    _passwordFocusNode.addListener(() {
      setState(() {
        _passwordFillColor = _passwordFocusNode.hasFocus
            ? const Color.fromARGB(0, 255, 255, 255)
            : const Color.fromARGB(107, 255, 255, 255);
      });
    });

    Future.delayed(const Duration(milliseconds: 100), () {
      setState(() {
        _isVisible = true;
      });
    });
  }

  @override
  void dispose() {
    _usernameController.dispose();
    _passwordController.dispose();
    _usernameFocusNode.dispose();
    _passwordFocusNode.dispose();
    super.dispose();
  }

  void _handleLogin(BuildContext context) {
    final username = _usernameController.text.trim();
    final password = _passwordController.text.trim();

    // Ensure you pass the UserDatabase instance here
    context.read<LoginCubit>().login(username, password);
  }

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) => LoginCubit(UserDatabase()), // Pass your UserDatabase instance
      child: Scaffold(
        backgroundColor: const Color.fromARGB(255, 12, 66, 4),
        body: BlocListener<LoginCubit, LoginState>(
          listener: (context, state) {
            if (state is LoginSuccessFarmer) {
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(
                  builder: (context) => MainPageFarmer(activeIndex: 4),
                ),
              );
            } else if (state is LoginSuccessSeller) {
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(
                  builder: (context) => MainPageSeller(activeIndex: 4),
                ),
              );
            } else if (state is LoginFailure) {
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text(state.error)),
              );
            }
          },
          child: Stack(
            children: [
              // Background Image
              Opacity(
                opacity: 0.7,
                child: Container(
                  decoration: BoxDecoration(
                    image: DecorationImage(
                      image: AssetImage('assets/backgroundlogin.jpg'),
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
              ),
              // Logo in the center
              Align(
                alignment: Alignment(0, -0.75),
                child: Container(
                  width: 122,
                  height: 122,
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(35),
                    child: Image.asset(
                      'assets/logo.png',
                    ),
                  ),
                ),
              ),
              // Login container at the bottom right
              AnimatedPositioned(
                duration: const Duration(milliseconds: 800),
                curve: Curves.easeOut,
                bottom: _isVisible ? 0 : -520,
                right: _isVisible ? 0 : -357,
                child: Padding(
                  padding: const EdgeInsets.all(0.0),
                  child: Container(
                    width: 357,
                    height: 520,
                    padding: const EdgeInsets.all(16.0),
                    decoration: BoxDecoration(
                      color: const Color.fromARGB(255, 12, 66, 4),
                      borderRadius:
                          const BorderRadius.only(topLeft: Radius.circular(71)),
                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          'مرحباً',
                          style: TextStyle(
                            fontSize: 32,
                            fontWeight: FontWeight.bold,
                            color: Colors.white,
                          ),
                        ),
                        const SizedBox(height: 20),
                        Container(
                          height: 50,
                          width: 310,
                          child: TextField(
                            controller: _usernameController,
                            style: const TextStyle(color: Color(0xFFBBB9B9)),
                            focusNode: _usernameFocusNode,
                            decoration: InputDecoration(
                              contentPadding: const EdgeInsets.symmetric(
                                  vertical: 16, horizontal: 50),
                              hintText:
                                  'اسم المستخدم، البريد الإلكتروني، أو رقم الهاتف',
                              hintStyle:
                                  const TextStyle(color: Color(0xFFBBB9B9)),
                              prefixIcon: const Padding(
                                padding: EdgeInsets.only(right: 8.0),
                                child: Icon(Icons.person,
                                    color: Color(0xFFBBB9B9)),
                              ),
                              filled: true,
                              fillColor: _usernameFillColor,
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(12),
                                borderSide: BorderSide.none,
                              ),
                              focusedBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(12),
                                borderSide: const BorderSide(
                                    color: Color.fromARGB(255, 71, 118, 0),
                                    width: 3.0),
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(height: 20),
                        Container(
                          height: 50,
                          width: 310,
                          child: TextField(
                            controller: _passwordController,
                            style: const TextStyle(color: Color(0xFFBBB9B9)),
                            focusNode: _passwordFocusNode,
                            obscureText: true,
                            decoration: InputDecoration(
                              contentPadding: const EdgeInsets.symmetric(
                                  vertical: 16, horizontal: 19),
                              hintText: 'كلمة السر',
                              hintStyle:
                                  const TextStyle(color: Color(0xFFBBB9B9)),
                              prefixIcon: const Icon(Icons.lock,
                                  color: Color(0xFFBBB9B9)),
                              suffixIcon: const Icon(Icons.visibility,
                                  color: Color(0xFFBBB9B9)),
                              filled: true,
                              fillColor: _passwordFillColor,
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(12),
                                borderSide: BorderSide.none,
                              ),
                              focusedBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(12),
                                borderSide: const BorderSide(
                                    color: Color.fromARGB(255, 71, 118, 0),
                                    width: 3.0),
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(height: 20),
                        ElevatedButton(
                          onPressed: () => _handleLogin(context),
                          style: ElevatedButton.styleFrom(
                            backgroundColor:
                                const Color.fromARGB(255, 71, 118, 0),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(10),
                            ),
                            fixedSize: const Size(310, 50),
                          ),
                          child: const Text(
                            'تسجيل الدخول',
                            style: TextStyle(fontSize: 16),
                          ),
                        ),
                        const SizedBox(height: 30),
                        TextButton(
                          onPressed: () {
                            Navigator.pushReplacement(
                              context,
                              MaterialPageRoute(
                                builder: (context) => const SignupPage(),
                              ),
                            );
                          },
                          child: const Text(
                            'لا تملك حساب؟ سجل الآن',
                            style: TextStyle(
                              fontSize: 14,
                              color: Color(0xFF909090),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
