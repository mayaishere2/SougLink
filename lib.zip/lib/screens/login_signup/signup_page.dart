import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class SignupPage extends StatefulWidget {
  const SignupPage({super.key});

  @override
  State<SignupPage> createState() => _SignupPageState();
}

class _SignupPageState extends State<SignupPage> {
  final FocusNode _usernameFocusNode = FocusNode();
  final FocusNode _phoneNumberFocusNode = FocusNode();
  final FocusNode _passwordFocusNode = FocusNode();
  final FocusNode _passwordConfirmFocusNode = FocusNode();
  Color _usernameFillColor = const Color.fromARGB(107, 255, 255, 255);
  Color _phoneNumberFillColor = const Color.fromARGB(107, 255, 255, 255);
  Color _passwordFillColor = const Color.fromARGB(107, 255, 255, 255);
  Color _passwordConfirmFillColor = const Color.fromARGB(107, 255, 255, 255);
  String? selectedUserType;
  final List<String> userTypes = ['تاجر سوق', 'مزارع'];
  DateTime? selectedDate;
  bool _isVisibile = false;
  bool _isLoading = false; // To track loading state

  final TextEditingController _usernameController = TextEditingController();
  final TextEditingController _phoneController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final TextEditingController _confirmPasswordController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _usernameFocusNode.addListener(() {
      setState(() {
        _usernameFillColor = _usernameFocusNode.hasFocus
            ? const Color.fromARGB(0, 255, 255, 255)
            : const Color.fromARGB(107, 255, 255, 255);
      });
    });
    _phoneNumberFocusNode.addListener(() {
      setState(() {
        _phoneNumberFillColor = _phoneNumberFocusNode.hasFocus
            ? const Color.fromARGB(0, 255, 255, 255)
            : const Color.fromARGB(107, 255, 255, 255);
      });
    });
    _passwordFocusNode.addListener(() {
      setState(() {
        _passwordFillColor = _passwordFocusNode.hasFocus
            ? const Color.fromARGB(0, 255, 255, 255)
            : const Color.fromARGB(107, 255, 255, 255);
      });
    });
    _passwordConfirmFocusNode.addListener(() {
      setState(() {
        _passwordConfirmFillColor = _passwordConfirmFocusNode.hasFocus
            ? const Color.fromARGB(0, 255, 255, 255)
            : const Color.fromARGB(107, 255, 255, 255);
      });
    });
    Future.delayed(const Duration(milliseconds: 100), () {
      setState(() {
        _isVisibile = true;
      });
    });
  }

  @override
  void dispose() {
    _usernameFocusNode.dispose();
    _phoneNumberFocusNode.dispose();
    _passwordFocusNode.dispose();
    _passwordConfirmFocusNode.dispose();
    _usernameController.dispose();
    _phoneController.dispose();
    _passwordController.dispose();
    _confirmPasswordController.dispose();
    super.dispose();
  }

  Future<void> _signup() async {
    if (_passwordController.text != _confirmPasswordController.text) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Passwords do not match")),
      );
      return;
    }

    setState(() {
      _isLoading = true; // Start loading
    });

    try {
      // Phone Number Authentication
      await FirebaseAuth.instance.verifyPhoneNumber(
        phoneNumber: _phoneController.text,
        verificationCompleted: (PhoneAuthCredential credential) async {
          await FirebaseAuth.instance.signInWithCredential(credential);
          await _storeUserData();
        },
        verificationFailed: (FirebaseAuthException e) {
          setState(() {
            _isLoading = false; // Stop loading on error
          });
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text("Verification failed: ${e.message}")),
          );
        },
        codeSent: (String verificationId, int? resendToken) {
          // Code sent, you can use the verificationId to complete the sign-in process
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text("Verification code sent")),
          );
        },
        codeAutoRetrievalTimeout: (String verificationId) {},
      );
    } catch (e) {
      setState(() {
        _isLoading = false; // Stop loading on error
      });
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Signup failed: ${e.toString()}")),
      );
    }
  }

  Future<void> _storeUserData() async {
    // After successful authentication, store user data in Firestore
    User? user = FirebaseAuth.instance.currentUser;
    if (user != null) {
      // Store additional user details in Firestore
      await FirebaseFirestore.instance.collection('users').doc(user.uid).set({
        'username': _usernameController.text,
        'phoneNumber': _phoneController.text,
        'userType': selectedUserType,
        'registrationDate': FieldValue.serverTimestamp(),
      });

      setState(() {
        _isLoading = false; // Stop loading after saving data
      });

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Signup successful")),
      );

      // Navigate to home or login page
      Navigator.pushReplacementNamed(context, '/home');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color.fromARGB(255, 12, 66, 4),
      body: Stack(
        children: [
          // Background Image
          Opacity(
            opacity: 0.7,
            child: Container(
              decoration: const BoxDecoration(
                image: DecorationImage(
                  image: AssetImage('assets/backgroundlogin.jpg'),
                  fit: BoxFit.cover,
                ),
              ),
            ),
          ),
          // Form Container
          AnimatedPositioned(
            duration: const Duration(milliseconds: 800),
            curve: Curves.easeOut,
            top: _isVisibile ? 0 : -750,
            left: _isVisibile ? 0 : -357,
            child: Container(
              width: 357,
              height: 750,
              padding: const EdgeInsets.all(16.0),
              decoration: const BoxDecoration(
                color: Color.fromARGB(255, 12, 66, 4),
                borderRadius: BorderRadius.only(bottomRight: Radius.circular(71)),
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Align(
                    alignment: const Alignment(-1, -1),
                    child: IconButton(
                      icon: const Icon(Icons.keyboard_arrow_left,
                          color: Colors.white, size: 25),
                      onPressed: () {
                        Navigator.pop(context);
                      },
                    ),
                  ),
                  const Text(
                    'التسجيل',
                    style: TextStyle(
                      fontSize: 32,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
                  const SizedBox(height: 20),
                  // Username Input
                  _buildTextField(
                      'اسم المستخدم', _usernameFocusNode, _usernameFillColor,
                      controller: _usernameController),
                  const SizedBox(height: 20),
                  // Phone Number Input
                  _buildTextField(
                      'رقم الهاتف', _phoneNumberFocusNode, _phoneNumberFillColor,
                      controller: _phoneController),
                  const SizedBox(height: 20),
                  // User Type Dropdown
                  _buildDropdown(),
                  const SizedBox(height: 20),
                  // Password Input
                  _buildTextField(
                      'كلمة المرور', _passwordFocusNode, _passwordFillColor,
                      isObscure: true, controller: _passwordController),
                  const SizedBox(height: 20),
                  // Confirm Password Input
                  _buildTextField('تأكيد كلمة المرور', _passwordConfirmFocusNode,
                      _passwordConfirmFillColor,
                      isObscure: true, controller: _confirmPasswordController),
                  const SizedBox(height: 50),
                  _isLoading
                      ? const CircularProgressIndicator() // Show loading indicator while signing up
                      : ElevatedButton(
                          onPressed: _signup, // Trigger the signup logic
                          style: ElevatedButton.styleFrom(
                            backgroundColor: const Color.fromARGB(255, 71, 118, 0),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12),
                            ),
                          ),
                          child: const Text('تسجيل', style: TextStyle(fontSize: 18)),
                        ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTextField(String hintText, FocusNode focusNode, Color fillColor,
      {bool isObscure = false, required TextEditingController controller}) {
    return Container(
      height: 50,
      width: 310,
      child: TextField(
        style: const TextStyle(color: Color(0xFFBBB9B9)),
        focusNode: focusNode,
        obscureText: isObscure,
        controller: controller,
        decoration: InputDecoration(
          contentPadding:
              const EdgeInsets.symmetric(vertical: 16, horizontal: 20),
          hintText: hintText,
          hintStyle: const TextStyle(color: Color(0xFFBBB9B9)),
          filled: true,
          fillColor: fillColor,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide.none,
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: const BorderSide(
                color: Color.fromARGB(255, 71, 118, 0), width: 3.0),
          ),
        ),
      ),
    );
  }

  Widget _buildDropdown() {
    return Container(
      height: 50,
      width: 310,
      padding: const EdgeInsets.symmetric(horizontal: 10),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(12),
        color: const Color.fromARGB(107, 255, 255, 255),
      ),
      child: DropdownButton<String>(
        value: selectedUserType,
        isExpanded: true,
        dropdownColor: const Color.fromARGB(255, 228, 243, 226),
        hint: const Text(
          'اختار نوع المستخدم',
          style: TextStyle(color: Color(0xFFBBB9B9)),
        ),
        icon: const Icon(Icons.arrow_drop_down, color: Color(0xFFBBB9B9)),
        onChanged: (String? newValue) {
          setState(() {
            selectedUserType = newValue;
          });
        },
        items: userTypes
            .map((value) => DropdownMenuItem<String>(
                  value: value,
                  child: Text(value, style: const TextStyle(color: Colors.black)),
                ))
            .toList(),
      ),
    );
  }
}
