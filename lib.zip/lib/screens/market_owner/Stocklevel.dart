import 'package:flutter/material.dart';
import 'StockHistory.dart';

class Stocklevel extends StatefulWidget {
  const Stocklevel({super.key});

  @override
  State<Stocklevel> createState() => _StocklevelState();
}

class _StocklevelState extends State<Stocklevel> {
  TextEditingController searchController = TextEditingController();
  String searchText = "";
  bool _showDetails = false;
  String _selectedItem = '';

  final List<Map<String, dynamic>> items = [
    {
      'title': 'طماطم',
      'amount': '70 كج.',
      'status': 'كافية.',
      'image': 'assets/images/tomato.jfif'
    },
    {
      'title': 'بصل',
      'amount': '10 كج.',
      'status': 'منخفضة.',
      'image': 'assets/images/onion.jfif'
    },
    {
      'title': 'خيار',
      'amount': '0 كج.',
      'status': 'نفدت.',
      'image': 'assets/images/cucumber.jpg'
    },
    {
      'title': 'تفاح',
      'amount': '2 كج.',
      'status': 'منخفضة.',
      'image': 'assets/images/apple.jpg'
    },
    {
      'title': 'ليمون',
      'amount': '15 كج.',
      'status': 'كافية.',
      'image': 'assets/images/limon.webp'
    },
    {
      'title': 'بصل',
      'amount': '15 كج.',
      'status': 'كافية.',
      'image': 'assets/images/onion.jfif'
    },
    {
      'title': 'طماطم',
      'amount': '34 كج.',
      'status': 'كافية.',
      'image': 'assets/images/tomato.jfif'
    },
    {
      'title': 'ليمون',
      'amount': '15 كج.',
      'status': 'كافية.',
      'image': 'assets/images/limon.webp'
    },
  ];

  String? getdetails(String item, String wanted) {
    for (var entry in items) {
      if (entry['title'] == item) {
        return entry[wanted];
      }
    }
    return null;
  }

  @override
  Widget build(BuildContext context) {
    List<Widget> cards = [];
    for (int i = 0; i < items.length; ++i) {
      cards.add(buildCard(
        items[i]['title'],
        items[i]['amount'],
        items[i]['status'],
        items[i]['image'],
      ));
    }
    ;

    return Scaffold(
      backgroundColor: const Color.fromARGB(255, 228, 243, 226),
      body: Stack(
        clipBehavior: Clip.none,
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(15, 40, 15, 0),
                child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      IconButton(
                        icon: const Icon(
                          Icons.menu,
                          color: Colors.black,
                        ),
                        onPressed: () {},
                      ),
                      Container(
                        width: 65,
                        height: 65,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(15),
                        ),
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(15),
                          child: Image.asset(
                            'assets/images/logo.png',
                            fit: BoxFit.cover,
                          ),
                        ),
                      ),
                    ]),
              ),
              SizedBox(
                height: 10,
              ),
              Align(
                alignment: Alignment(0.5, 0),
                child: Text(
                  'تحكم في مستويات',
                  style: TextStyle(
                      fontFamily: 'Kanit',
                      fontSize: 32,
                      color: Colors.black,
                      fontWeight: FontWeight.w700),
                  textDirection: TextDirection.rtl,
                  textAlign: TextAlign.right,
                ),
              ),
              SizedBox(
                height: 5,
              ),
              Align(
                alignment: Alignment(-0.5, 0),
                child: Text(
                  'تخزين  المنتجات',
                  style: TextStyle(
                      fontFamily: 'Kanit',
                      fontSize: 32,
                      color: const Color.fromARGB(255, 14, 78, 5),
                      fontWeight: FontWeight.w700),
                  textDirection: TextDirection.rtl,
                  textAlign: TextAlign.right,
                ),
              ),
              SizedBox(
                height: 35,
              ),
              Center(
                child: SizedBox(
                  width: MediaQuery.of(context).size.width * 0.7,
                  height: MediaQuery.of(context).size.height * 0.04,
                  child: TextField(
                    controller: searchController,
                    onChanged: (value) {
                      setState(() {
                        searchText = value;
                      });
                    },
                    decoration: InputDecoration(
                      hintText: 'بحث',
                      prefixIcon: const Icon(Icons.search),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(30),
                        borderSide: BorderSide.none,
                      ),
                      filled: true,
                      fillColor: const Color.fromARGB(153, 14, 78, 5),
                      contentPadding:
                          const EdgeInsets.symmetric(horizontal: 16),
                      hintTextDirection: TextDirection.rtl,
                    ),
                  ),
                ),
              ),
              SizedBox(
                height: 30,
              ),
              SingleChildScrollView(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(20, 20, 20, 0),
                  child: Text(
                    'قائمة المنتجات:',
                    style: TextStyle(
                        fontFamily: 'Kanit',
                        fontSize: 16,
                        color: Colors.black,
                        fontWeight: FontWeight.bold),
                    textDirection: TextDirection.rtl,
                    textAlign: TextAlign.right,
                  ),
                ),
              ),
              const SizedBox(height: 5),
              Expanded(
                child: ListView(
                  children: cards,
                ),
              ),
            ],
          ),
          if (_showDetails)
            Positioned(
              child: Center(
                  child: Container(
                child: StockHistoryPage(
                  selectedItem: _selectedItem,
                  items: items,
                ),
              )),
            ),
        ],
      ),
    );
  }

  Widget buildCard(
      String title, String amount, String status, String imagePath) {
    return Card(
      color: const Color.fromARGB(241, 240, 245, 239),
      margin: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Stack(
          clipBehavior: Clip.none,
          children: [
            Row(
              children: [
                SizedBox(width: 80),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      '$title, $amount',
                      style: TextStyle(
                          fontSize: 18,
                          fontFamily: 'Kanit',
                          fontWeight: FontWeight.bold),
                    ),
                    Text(
                      status,
                      style: TextStyle(
                          fontSize: 16,
                          fontFamily: 'Kanit',
                          color: Colors.grey[700]),
                    ),
                  ],
                ),
                Spacer(),
                SizedBox(
                  height: 20,
                  child: ElevatedButton(
                    onPressed: () {
                      setState(() {
                        _showDetails = true;
                        _selectedItem = title;
                      });
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color.fromARGB(255, 14, 78, 5),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(8)),
                    ),
                    child: Text(
                      'المزيد',
                      style: TextStyle(
                        color: Colors.white,
                        fontFamily: 'Kanit',
                        fontSize: 13,
                      ),
                    ),
                  ),
                ),
              ],
            ),
            Positioned(
              top: -20,
              right: -20,
              child: Container(
                width: 65,
                height: 52,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10),
                  image: DecorationImage(
                      image: AssetImage(imagePath), fit: BoxFit.cover),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
